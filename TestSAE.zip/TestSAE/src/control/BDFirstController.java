package control;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class BDFirstController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    public BDFirstController(Stage primaryStage){
        this.stage = primaryStage;
    }

    @FXML
    private Button accueilleMapButton;

    @FXML
    void clickMapAccueille(ActionEvent event) {
        try {
            // Charge le fichier FXML de la nouvelle scène
            Parent root = FXMLLoader.load(getClass().getResource("/resouxdhxhtces/fxml/'Page Map'.fxml"));
            
            // Récupère la scène actuelle à partir de l'événement'
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            
            // Change la scène du stage
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
