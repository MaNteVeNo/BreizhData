package view;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import control.BDFirstController;

public class BreizhDataApp extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        // Charger le fichier FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/SceneAccueille.fxml"));

        // Initialiser le contrôleur avec l'instance de Stage
        /*
        SceneController controller = new SceneController(primaryStage);
        loader.setController(controller);
        */

        // Charger la scène
        Parent root = loader.load();
        primaryStage.setTitle("BreizhData");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
